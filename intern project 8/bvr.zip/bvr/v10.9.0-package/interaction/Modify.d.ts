/**
 * @classdesc
 * Events emitted by {@link module:ol/interaction/Modify~Modify} instances are
 * instances of this type.
 */
export class ModifyEvent extends Event {
    /**
     * @param {ModifyEventType} type Type.
     * @param {Collection<Feature>} features
     * The features modified.
     * @param {import("../MapBrowserEvent.js").default} mapBrowserEvent
     * Associated {@link module:ol/MapBrowserEvent~MapBrowserEvent}.
     */
    constructor(type: ModifyEventType, features: Collection<Feature>, mapBrowserEvent: import("../MapBrowserEvent.js").default);
    /**
     * The features being modified.
     * @type {Collection<Feature>}
     * @api
     */
    features: Collection<Feature>;
    /**
     * Associated {@link module:ol/MapBrowserEvent~MapBrowserEvent}.
     * @type {import("../MapBrowserEvent.js").default}
     * @api
     */
    mapBrowserEvent: import("../MapBrowserEvent.js").default;
}
export default Modify;
export type SegmentData = {
    /**
     * Depth.
     */
    depth?: number[] | undefined;
    /**
     * Feature.
     */
    feature: Feature;
    /**
     * Geometry.
     */
    geometry: import("../geom/SimpleGeometry.js").default;
    /**
     * Index.
     */
    index?: number | undefined;
    /**
     * Segment.
     */
    segment: Array<Array<number>>;
    /**
     * FeatureSegments.
     */
    featureSegments?: SegmentData[] | undefined;
};
/**
 * A function that takes a {@link module :ol/Feature~Feature} and  returns `true` if
 * the feature may be modified or `false` otherwise.
 */
export type FilterFunction = (arg0: Feature) => boolean;
export type DragSegment = [SegmentData, number];
export type Options = {
    /**
     * A function that
     * takes a {@link module :ol/MapBrowserEvent~MapBrowserEvent} and returns a
     * boolean to indicate whether that event will be considered to add or move a
     * vertex to the sketch. Default is
     * {@link module :ol/events/condition.primaryAction}.
     */
    condition?: import("../events/condition.js").Condition | undefined;
    /**
     * A function
     * that takes a {@link module :ol/MapBrowserEvent~MapBrowserEvent} and returns a
     * boolean to indicate whether that event should be handled. By default,
     * {@link module :ol/events/condition.singleClick} with
     * {@link module :ol/events/condition.altKeyOnly} results in a vertex deletion.
     * This combination is handled by wrapping the two condition checks in a single function:
     * ```js
     * import { altKeyOnly, singleClick } from 'ol/events/condition.js';
     *
     * function (event) {
     * return altKeyOnly(event) && singleClick(event)
     * }
     * ```
     */
    deleteCondition?: import("../events/condition.js").Condition | undefined;
    /**
     * A
     * function that takes a {@link module :ol/MapBrowserEvent~MapBrowserEvent} and
     * returns a boolean to indicate whether a new vertex should be added to the sketch
     * features. Default is {@link module :ol/events/condition.always}.
     */
    insertVertexCondition?: import("../events/condition.js").Condition | undefined;
    /**
     * Pixel tolerance for considering the
     * pointer close enough to a segment or vertex for editing.
     */
    pixelTolerance?: number | undefined;
    /**
     * Style used for the modification point or vertex. For linestrings and polygons, this will
     * be the affected vertex, for circles a point along the circle, and for points the actual
     * point. If not configured, the default edit style is used (see {@link module :ol/style/Style~Style}).
     * When using a style function, the point feature passed to the function will have an `existing` property -
     * indicating whether there is an existing vertex underneath or not, a `features`
     * property - an array whose entries are the features that are being modified, and a `geometries`
     * property - an array whose entries are the geometries that are being modified. Both arrays are
     * in the same order. The `geometries` are only useful when modifying geometry collections, where
     * the geometry will be the particular geometry from the collection that is being modified.
     */
    style?: import("../style/Style.js").StyleLike | import("../style/flat.js").FlatStyleLike | undefined;
    /**
     * The vector source with
     * features to modify.  If a vector source is not provided, a feature collection
     * must be provided with the `features` option.
     */
    source?: VectorSource<Feature<import("../geom/Geometry.js").default, {
        [x: string]: any;
    }>> | undefined;
    /**
     * When configured, point
     * features will be considered for modification based on their visual appearance, instead of being within
     * the `pixelTolerance` from the pointer location. When a {@link module :ol/layer/BaseVector~BaseVectorLayer} is
     * provided, only the rendered representation of the features on that layer will be considered.
     */
    hitDetection?: boolean | import("../layer/BaseVector.js").default<any, any, any> | undefined;
    /**
     * The features the interaction works on.  If a feature collection is not
     * provided, a vector source must be provided with the `source` option.
     */
    features?: Collection<Feature<import("../geom/Geometry.js").default, {
        [x: string]: any;
    }>> | undefined;
    /**
     * A function that takes a {@link module :ol/Feature~Feature}and returns `true` if the feature may be modified or `false` otherwise.
     */
    filter?: FilterFunction | undefined;
    /**
     * Trace a portion of another geometry.
     * Tracing starts when two neighboring vertices are dragged onto a trace target, without any other modification in between..
     */
    trace?: boolean | import("../events/condition.js").Condition | undefined;
    /**
     * Source for features to trace.  If tracing is active and a `traceSource` is
     * not provided, the interaction's `source` will be used.  Tracing requires that the interaction is configured with
     * either a `traceSource` or a `source`.
     */
    traceSource?: VectorSource<Feature<import("../geom/Geometry.js").default, {
        [x: string]: any;
    }>> | undefined;
    /**
     * Wrap the world horizontally on the sketch
     * overlay.
     */
    wrapX?: boolean | undefined;
    /**
     * The vertex, point or segment being modified snaps to the
     * pointer coordinate when clicked within the `pixelTolerance`.
     */
    snapToPointer?: boolean | undefined;
    /**
     * A function that takes two coordinates and returns whether they should be
     * considered equal for vertex matching purposes. By default, all coordinate
     * dimensions are compared. This is useful when features have mixed coordinate
     * dimensions (e.g., XY and XYZ) but should still be treated as sharing vertices
     * at the same 2D position.
     */
    sharedVerticesEqual?: ((arg0: import("../coordinate.js").Coordinate, arg1: import("../coordinate.js").Coordinate) => boolean) | undefined;
};
/**
 * *
 */
export type ModifyOnSignature<Return> = import("../Observable.js").OnSignature<import("../Observable.js").EventTypes, import("../events/Event.js").default, Return> & import("../Observable.js").OnSignature<import("../ObjectEventType.js").Types | "change:active", import("../Object.js").ObjectEvent, Return> & import("../Observable.js").OnSignature<"modifyend" | "modifystart", ModifyEvent, Return> & import("../Observable.js").CombinedOnSignature<import("../Observable.js").EventTypes | import("../ObjectEventType.js").Types | "change:active" | "modifyend" | "modifystart", Return>;
import Event from '../events/Event.js';
import Collection from '../Collection.js';
import Feature from '../Feature.js';
type ModifyEventType = string;
declare namespace ModifyEventType {
    let MODIFYSTART: string;
    let MODIFYEND: string;
}
/***
 * @template Return
 * @typedef {import("../Observable.js").OnSignature<import("../Observable.js").EventTypes, import("../events/Event.js").default, Return> &
 *   import("../Observable.js").OnSignature<import("../ObjectEventType.js").Types|
 *     'change:active', import("../Object.js").ObjectEvent, Return> &
 *   import("../Observable.js").OnSignature<'modifyend'|'modifystart', ModifyEvent, Return> &
 *   import("../Observable.js").CombinedOnSignature<import("../Observable.js").EventTypes|import("../ObjectEventType.js").Types|
 *     'change:active'|'modifyend'|'modifystart', Return>} ModifyOnSignature
 */
/**
 * @classdesc
 * Interaction for modifying feature geometries.  To modify features that have
 * been added to an existing source, construct the modify interaction with the
 * `source` option.  If you want to modify features in a collection (for example,
 * the collection used by a select interaction), construct the interaction with
 * the `features` option.  The interaction must be constructed with either a
 * `source` or `features` option.
 *
 * Cartesian distance from the pointer is used to determine the features that
 * will be modified. This means that geometries will only be considered for
 * modification when they are within the configured `pixelTolerance`. For point
 * geometries, the `hitDetection` option can be used to match their visual
 * appearance.
 *
 * By default, the interaction will allow deletion of vertices when the `alt`
 * key is pressed.  To configure the interaction with a different condition
 * for deletion, use the `deleteCondition` option.
 * @fires ModifyEvent
 * @api
 */
declare class Modify extends PointerInteraction {
    /**
     * @param {Options} options Options.
     */
    constructor(options: Options);
    /**
     * @param {import("../source/Vector.js").VectorSourceEvent} event Event.
     * @private
     */
    private handleSourceAdd_;
    /**
     * @param {import("../source/Vector.js").VectorSourceEvent} event Event.
     * @private
     */
    private handleSourceRemove_;
    /**
     * @param {import("../Collection.js").CollectionEvent} event Event.
     * @private
     */
    private handleExternalCollectionAdd_;
    /**
     * @param {import("../Collection.js").CollectionEvent} event Event.
     * @private
     */
    private handleExternalCollectionRemove_;
    /**
     * Listener for features in external source or features collection.  Ensures the feature filter
     * is re-run and segment data is updated.
     * @param {import("../events/Event.js").default | import("../Object.js").ObjectEvent} evt Event.
     * @private
     */
    private handleFeatureChange_;
    /***
     * @type {ModifyOnSignature<import("../events.js").EventsKey>}
     */
    on: ModifyOnSignature<import("../events.js").EventsKey>;
    /***
     * @type {ModifyOnSignature<import("../events.js").EventsKey>}
     */
    once: ModifyOnSignature<import("../events.js").EventsKey>;
    /***
     * @type {ModifyOnSignature<void>}
     */
    un: ModifyOnSignature<void>;
    /**
     * @private
     * @type {import("../events/condition.js").Condition}
     */
    private condition_;
    /**
     * @private
     * @param {import("../MapBrowserEvent.js").default} mapBrowserEvent Browser event.
     * @return {boolean} Combined condition result.
     */
    private defaultDeleteCondition_;
    /**
     * @type {import("../events/condition.js").Condition}
     * @private
     */
    private deleteCondition_;
    /**
     * @type {import("../events/condition.js").Condition}
     * @private
     */
    private insertVertexCondition_;
    /**
     * Editing vertex.
     * @type {Feature<Point>}
     * @private
     */
    private vertexFeature_;
    /**
     * Segments intersecting {@link this.vertexFeature_} by segment uid.
     * @type {Object<string, boolean>}
     * @private
     */
    private vertexSegments_;
    /**
     * @type {import("../coordinate.js").Coordinate}
     * @private
     */
    private lastCoordinate_;
    /**
     * Tracks if the next `singleclick` event should be ignored to prevent
     * accidental deletion right after vertex creation.
     * @type {boolean}
     * @private
     */
    private ignoreNextSingleClick_;
    /**
     * @type {Collection<Feature>}
     * @private
     */
    private featuresBeingModified_;
    /**
     * Segment RTree for each layer
     * @type {RBush<SegmentData>}
     * @private
     */
    private rBush_;
    /**
     * @type {number}
     * @private
     */
    private pixelTolerance_;
    /**
     * @type {boolean}
     * @private
     */
    private snappedToVertex_;
    /**
     * Indicate whether the interaction is currently changing a feature's
     * coordinates.
     * @type {boolean}
     * @private
     */
    private changingFeature_;
    /**
     * @type {Array<DragSegment>}
     * @private
     */
    private dragSegments_;
    /**
     * Draw overlay where sketch features are drawn.
     * @type {VectorLayer}
     * @private
     */
    private overlay_;
    /**
     * @const
     * @private
     * @type {!Object<string, function(Feature, import("../geom/Geometry.js").default): void>}
     */
    private SEGMENT_WRITERS_;
    /**
     * @type {VectorSource}
     * @private
     */
    private source_;
    /**
     * @type {VectorSource|null}
     * @private
     */
    private traceSource_;
    /**
     * @type {import("../events/condition.js").Condition}
     * @private
     */
    private traceCondition_;
    /**
     * @type {import('./tracing.js').TraceState}
     * @private
     */
    private traceState_;
    /**
     * @type {Array<DragSegment>|null}
     * @private
     */
    private traceSegments_;
    /**
     * @type {boolean|import("../layer/BaseVector.js").default}
     * @private
     */
    private hitDetection_;
    /**
     * Useful for performance optimization
     * @private
     * @type boolean
     */
    private filterFunctionWasSupplied_;
    /**
     * @private
     * @type {FilterFunction}
     */
    private filter_;
    /**
     * @private
     * @type {function(import("../coordinate.js").Coordinate, import("../coordinate.js").Coordinate): boolean}
     */
    private coordinatesEqual_;
    featuresCollection_: Collection<Feature<import("../geom/Geometry.js").default, {
        [x: string]: any;
    }>> | undefined;
    /**
     * Internal features array.  When adding or removing features, be sure to use
     * addFeature_()/removeFeature_() so that the the segment index is adjusted.
     * @type {Array<Feature>}
     * @private
     */
    private features_;
    /**
     * @type {import("../MapBrowserEvent.js").default}
     * @private
     */
    private lastPointerEvent_;
    /**
     * Delta (x, y in map units) between matched rtree vertex and pointer vertex.
     * @type {Array<number>}
     * @private
     */
    private delta_;
    /**
     * @private
     */
    private snapToPointer_;
    /**
     * Toggle tracing mode or set a tracing condition.
     *
     * @param {boolean|import("../events/condition.js").Condition} trace A boolean to toggle tracing mode or an event
     *     condition that will be checked when a feature is clicked to determine if tracing should be active.
     */
    setTrace(trace: boolean | import("../events/condition.js").Condition): void;
    /**
     * Called when a feature is added to the internal features collection
     * @param {Feature} feature Feature.
     * @private
     */
    private addFeature_;
    /**
     * @param {import("../MapBrowserEvent.js").default} evt Map browser event.
     * @param {Array<SegmentData>} segments The segments subject to modification.
     * @private
     */
    private willModifyFeatures_;
    /**
     * Removes a feature from the internal features collection and updates internal state
     * accordingly.
     * @param {Feature} feature Feature.
     * @private
     */
    private removeFeature_;
    /**
     * @param {Feature} feature Feature.
     * @private
     */
    private removeFeatureSegmentData_;
    /**
     * Remove the interaction from its current map and attach it to the new map.
     * Subclasses may set up event handlers to get notified about changes to
     * the map here.
     * @param {import("../Map.js").default} map Map.
     * @override
     */
    override setMap(map: import("../Map.js").default): void;
    /**
     * Get the overlay layer that this interaction renders the modification point or vertex to.
     * @return {VectorLayer} Overlay layer.
     * @api
     */
    getOverlay(): VectorLayer;
    /**
     * Common handler for event signaling addition of feature to the supplied features source
     * or collection.
     * @param {Feature} feature Feature.
     */
    externalAddFeatureHandler_(feature: Feature): void;
    /**
     * Common handler for event signaling removal of feature from the supplied features source
     * or collection.
     * @param {Feature} feature Feature.
     */
    externalRemoveFeatureHandler_(feature: Feature): void;
    /**
     * @param {Feature} feature Feature
     * @param {Point} geometry Geometry.
     * @private
     */
    private writePointGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/MultiPoint.js").default} geometry Geometry.
     * @private
     */
    private writeMultiPointGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/LineString.js").default} geometry Geometry.
     * @private
     */
    private writeLineStringGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/MultiLineString.js").default} geometry Geometry.
     * @private
     */
    private writeMultiLineStringGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/Polygon.js").default} geometry Geometry.
     * @private
     */
    private writePolygonGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/MultiPolygon.js").default} geometry Geometry.
     * @private
     */
    private writeMultiPolygonGeometry_;
    /**
     * We convert a circle into two segments.  The segment at index
     * {@link CIRCLE_CENTER_INDEX} is the
     * circle's center (a point).  The segment at index
     * {@link CIRCLE_CIRCUMFERENCE_INDEX} is
     * the circumference, and is not a line segment.
     *
     * @param {Feature} feature Feature.
     * @param {import("../geom/Circle.js").default} geometry Geometry.
     * @private
     */
    private writeCircleGeometry_;
    /**
     * @param {Feature} feature Feature
     * @param {import("../geom/GeometryCollection.js").default} geometry Geometry.
     * @private
     */
    private writeGeometryCollectionGeometry_;
    /**
     * @param {import("../coordinate.js").Coordinate} coordinates Coordinates.
     * @param {Array<Feature>} features The features being modified.
     * @param {Array<import("../geom/SimpleGeometry.js").default>} geometries The geometries being modified.
     * @param {boolean} existing The vertex represents an existing vertex.
     * @return {Feature} Vertex feature.
     * @private
     */
    private createOrUpdateVertexFeature_;
    /**
     * @param {import("../coordinate.js").Coordinate} pixelCoordinate Pixel coordinate.
     * @return {Array<SegmentData>|undefined} Insert vertices and update drag segments.
     * @private
     */
    private findInsertVerticesAndUpdateDragSegments_;
    /**
     * @private
     */
    private deactivateTrace_;
    /**
     * Update the trace.
     * @param {import("../MapBrowserEvent.js").default} event Event.
     * @private
     */
    private updateTrace_;
    getTraceCandidates_(event: any): Feature<import("../geom/Geometry.js").default, {
        [x: string]: any;
    }>[];
    /**
     * Activate or deactivate trace state based on a browser event.
     * @param {import("../MapBrowserEvent.js").default} event Event.
     * @private
     */
    private toggleTraceState_;
    /**
     * @param {import('./tracing.js').TraceTarget} target The trace target.
     * @param {number} endIndex The new end index of the trace.
     * @private
     */
    private addOrRemoveTracedCoordinates_;
    /**
     * @param {number} fromIndex The start index.
     * @param {number} toIndex The end index.
     * @private
     */
    private removeTracedCoordinates_;
    /**
     * @param {import('./tracing.js').TraceTarget} target The trace target.
     * @param {number} fromIndex The start index.
     * @param {number} toIndex The end index.
     * @private
     */
    private addTracedCoordinates_;
    /**
     * @param {import('../coordinate.js').Coordinate} vertex Vertex.
     * @param {DragSegment} dragSegment Drag segment.
     */
    updateGeometry_(vertex: import("../coordinate.js").Coordinate, dragSegment: DragSegment): void;
    /**
     * @param {import("../MapBrowserEvent.js").default} evt Event.
     * @private
     */
    private handlePointerMove_;
    /**
     * @param {import("../coordinate.js").Coordinate} pixelCoordinate The pixel Coordinate.
     * @private
     */
    private handlePointerAtPixel_;
    /**
     * @param {SegmentData} segmentData Segment data.
     * @param {import("../coordinate.js").Coordinate} vertex Vertex.
     * @return {boolean} A vertex was inserted.
     * @private
     */
    private insertVertex_;
    /**
     * @param {import("../coordinate.js").Coordinate} coordinate The coordinate.
     * @return {import("../coordinate.js").Coordinate} The updated pointer coordinate.
     * @private
     */
    private updatePointer_;
    /**
     * Get the current pointer position.
     * @return {import("../coordinate.js").Coordinate | null} The current pointer coordinate.
     */
    getPoint(): import("../coordinate.js").Coordinate | null;
    /**
     * Check if a point can be removed from the current linestring or polygon at the current
     * pointer position.
     * @return {boolean} A point can be deleted at the current pointer position.
     * @api
     */
    canRemovePoint(): boolean;
    /**
     * Removes the vertex currently being pointed from the current linestring or polygon.
     * @param {import('../coordinate.js').Coordinate} [coordinate] If provided, the pointer
     * will be set to the provided coordinate. If not, the current pointer coordinate will be used.
     * @return {boolean} True when a vertex was removed.
     * @api
     */
    removePoint(coordinate?: import("../coordinate.js").Coordinate): boolean;
    /**
     * Removes a vertex from all matching features.
     * @return {boolean} True when a vertex was removed.
     * @private
     */
    private removeVertex_;
    /**
     * Check if a point can be inserted to the current linestring or polygon at the current
     * pointer position.
     * @return {boolean} A point can be inserted at the current pointer position.
     * @api
     */
    canInsertPoint(): boolean;
    /**
     * Inserts the vertex currently being pointed to the current linestring or polygon.
     * @param {import('../coordinate.js').Coordinate} [coordinate] If provided, the pointer
     * will be set to the provided coordinate. If not, the current pointer coordinate will be used.
     * @return {boolean} A vertex was inserted.
     * @api
     */
    insertPoint(coordinate?: import("../coordinate.js").Coordinate): boolean;
    /**
     * @param {import("../geom/SimpleGeometry.js").default} geometry Geometry.
     * @param {Array} coordinates Coordinates.
     * @private
     */
    private setGeometryCoordinates_;
    /**
     * @param {import("../geom/SimpleGeometry.js").default} geometry Geometry.
     * @param {number} index Index.
     * @param {Array<number>|undefined} depth Depth.
     * @param {number} delta Delta (1 or -1).
     * @private
     */
    private updateSegmentIndices_;
}
import VectorSource from '../source/Vector.js';
import PointerInteraction from './Pointer.js';
import VectorLayer from '../layer/Vector.js';
//# sourceMappingURL=Modify.d.ts.map