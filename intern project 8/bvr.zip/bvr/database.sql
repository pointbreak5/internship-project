CREATE DATABASE dashboarddb;

-- Connect to dashboarddb

CREATE TABLE aircraft (
    id SERIAL PRIMARY KEY,
    aircraft_name VARCHAR(100),
    status VARCHAR(30),
    date DATE,
    duration VARCHAR(30),
    aircraft_count INT
);

INSERT INTO aircraft (
    aircraft_name,
    status,
    date,
    duration,
    aircraft_count
)
VALUES (
    'Mark 15',
    'Completed',
    '2026-07-11',
    '45 mins',
    4
);

CREATE TABLE performance (
    id SERIAL PRIMARY KEY,
    accuracy INT,
    efficiency INT,
    survivability INT
);

INSERT INTO performance (
    accuracy,
    efficiency,
    survivability
)
VALUES (
    88,
    58,
    90
);

--objective assessment
CREATE TABLE objective_assessment (
    id SERIAL PRIMARY KEY,
    objective VARCHAR(100),
    weight VARCHAR(10),
    status VARCHAR(20),
    score VARCHAR(20)
);
-- values
INSERT INTO objective_assessment (objective, weight, status, score)
VALUES
('Detect Target', '30%', 'COMPLETED', '18/20'),
('Maintain EMCON', '20%', 'PARTIAL', '12/20'),
('Detect Target', '30%', 'COMPLETED', '30/30');

--instruction summary
CREATE TABLE instructor_summary (
    summary_id SERIAL PRIMARY KEY,
    mission_id INT,

    operational_awareness INT CHECK (operational_awareness BETWEEN 1 AND 5),
    tactical_decision_making INT CHECK (tactical_decision_making BETWEEN 1 AND 5),
    communication INT CHECK (communication BETWEEN 1 AND 5),
    roe_compliance INT CHECK (roe_compliance BETWEEN 1 AND 5),

    instructor_comments TEXT,

    instructor_name VARCHAR(100)
);
--values
INSERT INTO instructor_summary
(
    mission_id,
    operational_awareness,
    tactical_decision_making,
    communication,
    roe_compliance,
    instructor_comments,
    instructor_name
)
VALUES
(
    1,
    4,
    3,
    5,
    4,
    'Good overall performance. Strong in contact classification and convoy protection. Need improvement in EMCON discipline and timely threat reporting.',
    'LCDR A. Sharma'
);

--update comment
UPDATE instructor_summary
SET instructor_comments = 'Excellent mission execution. Maintain better communication during high-threat situations.'
WHERE summary_id = 1;

--communication review
CREATE TABLE communication_log (
    log_id SERIAL PRIMARY KEY,
    timestamp TIME,
    sender VARCHAR(30),
    receiver VARCHAR(30),
    message TEXT,
    status VARCHAR(20)
);

INSERT INTO communication_log
(timestamp, sender, receiver, message, status)
VALUES
('14:02:15','AWACS','Eagle-1','Bogey detected 80 NM','Delivered'),

('14:03:47','Eagle-1','Formation','Fox-3 launched','Delivered'),

('14:04:21','Falcon-2','Eagle-1','Defensive left','Delayed'),

('14:05:32','Eagle-1','AWACS','Splash confirmed','Delivered');

--mission timeline
CREATE TABLE mission_timeline (
    timeline_id SERIAL PRIMARY KEY,
    event_time TIME,
    event_name VARCHAR(100),
    description TEXT,
    status VARCHAR(20)
);

INSERT INTO mission_timeline
(event_time, event_name, description, status)
VALUES
('09:00:00','Takeoff','Aircraft departed from base','info'),

('09:08:00','Target Detected','AWACS detected hostile aircraft','info'),

('09:12:00','Radar Lock','Target locked successfully','warning'),

('09:18:00','Fox-3 Launch','AIM-120 missile launched','success'),

('09:19:00','Missile Active','Missile entered terminal guidance','info'),

('09:22:00','Splash Confirmed','Hostile aircraft destroyed','success'),

('09:25:00','RTB','Aircraft returning to base','info'),

('09:35:00','Mission Complete','Mission ended successfully','success');

--Decision table
CREATE TABLE decision_points (

    decision_id SERIAL PRIMARY KEY,

    event_time TIME,
    decision_event VARCHAR(100),
    action_taken TEXT,
    roe_outcome VARCHAR(30),
    audit_status VARCHAR(50),
    threat_level VARCHAR(30),
    decision_by VARCHAR(50),
    response_time INT,
    remarks TEXT

);

iINSERT INTO decision_points
(event_time, decision_event, action_taken, roe_outcome, audit_status, threat_level, decision_by, response_time, remarks)

VALUES

('09:08:00',
'Hostile Identification',
'Confirmed Bogey-1 using AWACS radar correlation.',
'PASSED',
'Verified',
'Medium',
'Mission Commander',
12,
'Target classified as hostile after positive identification.'),

('09:18:00',
'Weapons Release',
'Launched AIM-120 Fox-3 missile within engagement envelope.',
'PASSED',
'Audit Approved',
'High',
'Flight Lead',
8,
'Missile launch complied with all Rules of Engagement.');


--ADD coloumn
ALTER TABLE decision_points
ADD COLUMN mission_phase VARCHAR(50);

--changes value inside table
UPDATE decision_points
SET mission_phase = 'Detection'
WHERE decision_id = 1;

--add coloumn
ALTER TABLE performance ADD COLUMN survivability INT; 
UPDATE performance SET survivability = 90;

--add values
INSERT INTO decision_points (average)
VALUES (78.8);

--------------------------DUMMY DATA----------------------------------------------------------------
INSERT INTO decision_points (
event_time,
decision_event,
action_taken,
roe_outcome,
audit_status,
threat_level,
decision_by,
response_time,
remarks,
mission_phase,
average,
overall,
instructor,
action,
replay,
more_feedback,
selection
)
VALUES
('08:00:15','Radar Contact','Target Locked','Approved','Verified','Medium','Pilot',3,'Initial contact established','Detection',82,'Mission Success: 82%','Capt. Sharma','Maintain Radar Lock','Available','Maintain radar lock discipline.','Mission 01'),

('08:01:42','Hostile Identified','IFF Confirmed','Approved','Verified','High','Mission Commander',2,'Hostile aircraft confirmed','Identification',88,'Mission Success: 88%','Capt. Sharma','Prepare Engagement','Available','Good identification process.','Mission 02'),

('08:03:10','Missile Launch','BVR Missile Fired','Approved','Verified','Critical','Pilot',4,'Successful launch','Engagement',91,'Mission Success: 91%','Wing Cmdr. Verma','Maintain Course','Available','Launch timing was accurate.','Mission 03'),

('08:05:18','Enemy Evasive','Tracking Continued','Approved','Verified','High','Pilot',5,'Target attempting escape','Tracking',84,'Mission Success: 84%','Wing Cmdr. Verma','Continue Tracking','Available','Improve tracking stability.','Mission 04'),

('08:06:35','Countermeasure Detected','ECCM Activated','Approved','Verified','Critical','Mission Commander',3,'Enemy deployed flares','Countermeasure',90,'Mission Success: 90%','Sqn. Ldr. Mehta','ECCM Enabled','Available','Good electronic response.','Mission 05'),

('08:08:12','Missile Hit','Target Destroyed','Approved','Verified','Critical','Pilot',2,'Direct impact achieved','Kill Confirmation',96,'Mission Success: 96%','Sqn. Ldr. Mehta','Confirm Kill','Available','Excellent engagement.','Mission 06'),

('08:10:24','New Contact','Radar Scan','Approved','Verified','Low','Radar Operator',4,'Secondary contact found','Detection',79,'Mission Success: 79%','Capt. Sharma','Continue Scan','Available','Maintain scan coverage.','Mission 07'),

('08:11:46','Formation Update','Wingman Joined','Approved','Verified','Low','Pilot',3,'Formation restored','Coordination',86,'Mission Success: 86%','Capt. Sharma','Maintain Formation','Available','Coordination improved.','Mission 08'),

('08:13:08','Threat Increased','Combat Mode','Approved','Verified','Critical','Mission Commander',2,'Enemy approaching rapidly','Alert',92,'Mission Success: 92%','Wing Cmdr. Verma','Combat Ready','Available','Excellent response time.','Mission 09'),

('08:14:55','Fuel Check','Mission Continued','Approved','Verified','Low','Pilot',4,'Fuel within limits','Support',80,'Mission Success: 80%','Wing Cmdr. Verma','Monitor Fuel','Available','Fuel management satisfactory.','Mission 10'),

('08:16:10','Communication Restored','Secure Link Active','Approved','Verified','Medium','Communication Officer',3,'Link stabilized','Communication',87,'Mission Success: 87%','Sqn. Ldr. Mehta','Maintain Link','Available','Stable communication.','Mission 11'),

('08:18:20','Target Locked','Tracking Stable','Approved','Verified','High','Pilot',2,'Tracking accuracy improved','Tracking',90,'Mission Success: 90%','Sqn. Ldr. Mehta','Maintain Lock','Available','Accurate lock maintained.','Mission 12'),

('08:19:52','Weapon Armed','Ready to Fire','Approved','Verified','High','Pilot',3,'Weapon system ready','Preparation',89,'Mission Success: 89%','Capt. Sharma','Prepare Launch','Available','Weapons prepared successfully.','Mission 13'),

('08:21:14','ROE Check','Rules Confirmed','Approved','Verified','Medium','Mission Commander',2,'ROE verified','Verification',85,'Mission Success: 85%','Capt. Sharma','Proceed','Available','ROE followed correctly.','Mission 14'),

('08:22:39','Enemy Jammer','Frequency Changed','Approved','Verified','High','Communication Officer',4,'Jamming minimized','Electronic Warfare',88,'Mission Success: 88%','Wing Cmdr. Verma','Change Frequency','Available','Good anti-jamming response.','Mission 15'),

('08:24:01','Navigation Update','Waypoint Reached','Approved','Verified','Low','Pilot',3,'Aircraft on planned route','Navigation',84,'Mission Success: 84%','Wing Cmdr. Verma','Continue Route','Available','Navigation accurate.','Mission 16'),

('08:25:22','Missile Impact','Confirmed Kill','Approved','Verified','Critical','Pilot',2,'Enemy destroyed','Kill Confirmation',97,'Mission Success: 97%','Sqn. Ldr. Mehta','Mission Continue','Available','Outstanding performance.','Mission 17'),

('08:27:16','Threat Neutralized','Area Secure','Approved','Verified','Low','Mission Commander',3,'Sector secured','Completion',93,'Mission Success: 93%','Sqn. Ldr. Mehta','Secure Area','Available','Mission progressing well.','Mission 18'),

('08:28:54','Recon Update','Enemy Movement','Approved','Verified','Medium','Radar Operator',4,'Enemy repositioning','Recon',82,'Mission Success: 82%','Capt. Sharma','Observe','Available','Maintain surveillance.','Mission 19'),

('08:30:20','Formation Split','Independent Search','Approved','Verified','Medium','Mission Commander',5,'Aircraft separated','Search',81,'Mission Success: 81%','Capt. Sharma','Search Area','Available','Coordinate effectively.','Mission 20'),

('08:31:42','Visual Contact','Enemy Confirmed','Approved','Verified','High','Pilot',2,'Visual acquired','Identification',94,'Mission Success: 94%','Wing Cmdr. Verma','Engage','Available','Strong visual confirmation.','Mission 21'),

('08:33:10','Radar Sweep','Area Clear','Approved','Verified','Low','Radar Operator',3,'No additional threats','Detection',86,'Mission Success: 86%','Wing Cmdr. Verma','Continue Sweep','Available','Excellent coverage.','Mission 22'),

('08:34:45','Missile Armed','Standby','Approved','Verified','High','Pilot',2,'Ready for engagement','Preparation',88,'Mission Success: 88%','Sqn. Ldr. Mehta','Standby','Available','Await further orders.','Mission 23'),

('08:36:05','Enemy Locked','Final Tracking','Approved','Verified','Critical','Pilot',2,'Tracking stable','Tracking',95,'Mission Success: 95%','Sqn. Ldr. Mehta','Final Lock','Available','Excellent tracking.','Mission 24'),

('08:37:18','Launch Approved','Weapon Fired','Approved','Verified','Critical','Mission Commander',2,'Launch executed','Engagement',96,'Mission Success: 96%','Capt. Sharma','Fire','Available','Excellent decision making.','Mission 25'),

('08:39:06','Target Down','Kill Confirmed','Approved','Verified','Critical','Pilot',2,'Mission objective achieved','Completion',98,'Mission Success: 98%','Capt. Sharma','Return Base','Available','Outstanding execution.','Mission 26'),

('08:40:52','Debrief Started','Mission Review','Approved','Verified','Low','Instructor',4,'Review initiated','Debrief',90,'Mission Success: 90%','Wing Cmdr. Verma','Review Replay','Available','Discuss improvements.','Mission 27'),

('08:42:10','Performance Review','Metrics Generated','Approved','Verified','Low','Instructor',3,'Performance recorded','Analysis',91,'Mission Success: 91%','Wing Cmdr. Verma','Evaluate','Available','Very good mission.','Mission 28'),

('08:43:35','Training Complete','Mission Closed','Approved','Verified','Low','Instructor',2,'Training finished','Completion',94,'Mission Success: 94%','Sqn. Ldr. Mehta','Archive Mission','Available','Mission archived successfully.','Mission 29'),

('08:45:00','Final Assessment','Mission Passed','Approved','Verified','Low','Instructor',2,'Final assessment complete','Debrief',95,'Mission Success: 95%','Capt. Sharma','Close Mission','Available','Excellent overall performance.','Mission 30');